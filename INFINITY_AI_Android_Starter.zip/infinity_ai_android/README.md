# INFINITY AI — Android Starter

This is an Android Studio project for an offline-first starter edition of INFINITY AI. It includes a mathematical calculator, a Monte Carlo possibility simulator, and a local hypothesis notebook. Saved hypotheses are stored on the device using browser local storage.

## Build the APK
1. Download and install Android Studio.
2. Open this folder (`infinity_ai_android`) in Android Studio.
3. Allow Gradle sync and install Android SDK Platform 35 if prompted.
4. Choose **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. The debug APK will be at `app/build/outputs/apk/debug/app-debug.apk`.

## Automated build
Push this folder to a GitHub repository. The included GitHub Actions workflow builds a debug APK. Download it from the workflow run's **Artifacts** section.

## Important limitations
This is a starter Android app, not the earlier Python/Streamlit application wrapped unchanged. It runs locally and does not include a large language model or cloud AI. It cannot prove speculative claims or discover a final theory of everything. The math calculator is for ordinary arithmetic and common JavaScript Math functions; do not enter untrusted code.
